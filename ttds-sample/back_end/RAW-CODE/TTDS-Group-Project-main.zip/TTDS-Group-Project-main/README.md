# TTDS-Group-Project
This is the Group project for course Text Technologies for Data Science (2020-2021). Our team number is 24.

__Porject Plan__: 
You can read project plan in file "TTDS Group Project Plan.pdf". If you want to edit this file, then go to: https://cn.overleaf.com/3965649579dgmpdtsvqmtt.

__Data Collections__:
The data sets we use in this project are:
1.  IMDb Largest Review Dataset part-1 (Number of reviews = 1, 010, 293)
(https://www.kaggle.com/ebiswas/imdb-review-dataset)
2.  MovieLens 25M Dataset
(https://grouplens.org/datasets/movielens/25m/)

___These database file should be download and put under the "data" fold.___
